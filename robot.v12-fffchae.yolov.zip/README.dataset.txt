# robot > FFFCHAE
https://universe.roboflow.com/-rfh1u/robot-kmovk

Provided by a Roboflow user
License: CC BY 4.0

